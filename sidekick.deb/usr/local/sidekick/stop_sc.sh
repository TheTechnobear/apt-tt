#/bin/bash

sudo killall jackd
#sudo systemctl stop norns-jack.service
sleep 1

